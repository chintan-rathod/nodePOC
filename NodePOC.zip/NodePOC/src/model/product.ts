import {Entity, Column,  PrimaryGeneratedColumn, ManyToOne, JoinColumn} from "typeorm";

@Entity("Product")
export class Product
{
    @PrimaryGeneratedColumn({ name: "Id", type: "int" })
    id:number ;

    @Column({ name: "name", length: 100 })
    productName:string;

    @Column({ name: "description", length: 200 })
    description:string;

    @Column({ name: "price", type: "decimal", precision: 8, scale: 2, nullable: true })
    price:number;

    @Column({ name: "Quantity", type: "smallint" })
    quantity:number;

    @Column({ name: "merchantID", type: "smallint" })
    merchantID:number;
}