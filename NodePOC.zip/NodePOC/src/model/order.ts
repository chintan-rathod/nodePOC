import {Entity, Column,  PrimaryGeneratedColumn, ManyToOne, JoinColumn, OneToMany} from "typeorm";
import { OrderDetail } from "./orderdetail";

@Entity("orders")
export class Orders
{
    @PrimaryGeneratedColumn({ name: "Id", type: "int" })
    id:number ;

    @Column({ name: "userid", length: 100 })
    userid:string;

    @Column({ name: "iscart", type: "bit" })
    iscart:boolean;

       @OneToMany(type => OrderDetail, detail => detail.order)

      orderdetail: OrderDetail[];
}