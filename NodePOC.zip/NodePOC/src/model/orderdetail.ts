import {Entity, Column,  PrimaryGeneratedColumn, ManyToOne, JoinColumn} from "typeorm";
import { Orders } from "./order";

@Entity("orderdetail")
export class OrderDetail
{
    @PrimaryGeneratedColumn({ name: "Id", type: "int" })
    id:number ;

    @Column({ name: "orderid" })
    orderid:string;

    @Column({ name: "productid", type: "int" })
    productid:number;

    @Column({ name: "quantity", type: "int" })
    quantity:number;
       @ManyToOne(type => Orders, order => order.orderdetail ,{cascade:true,eager:true})
       @JoinColumn({ name: 'orderid' })
       order: Orders;

}