const TYPES = {
    ProductRepository: Symbol('ProductRepository'),
    ProductService: Symbol('ProductService'),
    Controller: Symbol('Controller'),
    Product:Symbol('Product'),
    OrderDetail:Symbol('orderDetail'),
    OrderRepository: Symbol('orderRepository'),
    OrderService: Symbol('OrderService'),
};

export default TYPES;