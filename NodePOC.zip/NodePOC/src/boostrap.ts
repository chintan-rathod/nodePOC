import bodyParser from "body-parser";
import { getSqlDbConnection } from "./Repositories/dbConnction";
import { Container } from "inversify";
import TYPES from "./type";
import { IProductService, ProductService } from "./services/product.service";
import { ProductRepository } from "./Repositories/productRepository";
import { IproductRepository } from "./Repositories/productRepository";
import { Product } from "./model/product";
import { getRepository,Repository as TypeOrmRepository } from 'typeorm';
import { InversifyExpressServer } from "inversify-express-utils";
import { IorderService, OrderService } from "./services/order.service";
import { IorderRepository, OrderRepository } from "./Repositories/orderRepository";
import { OrderDetail } from "./model/orderdetail";

export async function bootstrapProcess(  port:number)

{
    await    getSqlDbConnection();

    const container = new Container();

// set up bindings
container.bind<IProductService>(TYPES.ProductService).to(ProductService);
container.bind<IproductRepository>(TYPES.ProductRepository).to(ProductRepository);
container.bind<IorderService>(TYPES.OrderService).to(OrderService);
container.bind<IorderRepository>(TYPES.OrderRepository).to(OrderRepository);
container.bind<TypeOrmRepository<Product>>(TYPES.Product)
.toDynamicValue(() => {
    return getRepository(Product);
})
.inTransientScope();

container.bind<TypeOrmRepository<OrderDetail>>(TYPES.OrderDetail)
.toDynamicValue(() => {
    return getRepository(OrderDetail);
})
.inTransientScope();

// create server
const server = new InversifyExpressServer(container);


server.setConfig((app1) => {
  // add body parser
  app1.use(bodyParser.urlencoded({
    extended: true
  }));
  app1.use(bodyParser.json());

});

const app2 = server.build();
app2.listen(port);
}