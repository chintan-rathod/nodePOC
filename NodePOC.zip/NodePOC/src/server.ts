import dotenv from "dotenv";
import App from "./app";
import { ProductController } from "./controller/product.Controller";
import container from "./services/ServiceFactory";
import { IProductService } from "./services/product.service";
import TYPES from "./type";

dotenv.config();
const port = process.env.SERVER_PORT;

const app = new App(
  [
   // new ProductController(container.get<IProductService>(TYPES.ProductService))
  ],
  port,
);

  app.listen();
