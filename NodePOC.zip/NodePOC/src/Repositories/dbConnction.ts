import {createConnections, Connection, createConnection} from "typeorm";
import { Product } from "../model/product";
import { OrderDetail } from "../model/orderdetail";
import { Orders } from "../model/order";

export async function getSqlDbConnection(): Promise<Connection | undefined>

{

    const entities1 = [Product,OrderDetail, Orders];
const connections = await createConnection({
        type: "mssql",
        username: "sa",
         password: "pass@word1",
         database: "shoppingcart",
        host: "localhost",
         port: 1434,
         entities: entities1,
        synchronize: false,
         options: { encrypt: true },
        logging: true
      });
      return connections;
}

