import { BaseRepository } from "./BaseRepository";

import { injectable, inject } from "inversify";
import { Product } from "../model/product";
import { getRepository, Repository } from "typeorm";
import TYPES from "../type";
@injectable()
export class ProductRepository extends BaseRepository<Product> implements IproductRepository {


    constructor(@inject(TYPES.Product) typeormrepo:Repository<Product> ) {

        super(typeormrepo);
    }

    async getAllProduct(flag: boolean, vendorNo: number): Promise<Product[]> {
        if (!flag) {

            return await this.find();
        } else {
            return await this.repo1.find({ merchantID: vendorNo });
            //    return this.repo1
            //     .createQueryBuilder('product')
            //     .where('"merchantID" = :merchantID', { vendorNo })

        }

    }

    async getSelectedProduct(id: string): Promise<Product> {
        return await this.findOne(id);
    }
    async updateProduct(productDetai: Product): Promise<Product> {
        // return await this.repo1.update(
        //     productDetai.id,
        //     productDetai,
        // )
          await this.update(productDetai.id.toString(), productDetai);
          return await  this.findOne(productDetai.id.toString());
    }
    async deleteProduct(id: string): Promise<any> {
        return await this.delete(id)
    }
    async addProduct(poductdetai: Product): Promise<Product> {
        return await this.create(poductdetai)

    }


}

export interface IproductRepository {
    getAllProduct(flag: boolean, vendorNo: number): Promise<Product[]>;
    getSelectedProduct(id: string): Promise<Product>;
    updateProduct(productDetai: Product): Promise<Product>;
    deleteProduct(id: string): Promise<boolean>;
    addProduct(poductdetai: Product): Promise<Product>;
}

