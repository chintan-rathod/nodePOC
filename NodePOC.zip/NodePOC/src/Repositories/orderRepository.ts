import { BaseRepository } from "./BaseRepository";

import { injectable, inject } from "inversify";
import { Product } from "../model/product";
import { getRepository, Repository, getConnection, createQueryBuilder } from "typeorm";
import TYPES from "../type";
import { OrderDetail } from "../model/orderdetail";
import { Orders } from "../model/order";
import { promises } from "fs";
@injectable()
export class OrderRepository extends BaseRepository<OrderDetail> implements IorderRepository {


    constructor(@inject(TYPES.OrderDetail) typeormrepo: Repository<OrderDetail>) {

        super(typeormrepo);
    }

    async getAllOrder(userid: number, iscart: boolean): Promise<any[]> {
        if (iscart) {
            const result = await getConnection().getRepository("Orders").createQueryBuilder("order")
                .innerJoinAndSelect("order.orderdetail", "orderdet")
                .where("order.userid = :userid", { userid })
                .andWhere("order.iscart = :iscart", { iscart: 1 })
                .getMany();
            return result;
        }
        else {
            const result = await getConnection().getRepository("Orders").createQueryBuilder("order")
                .innerJoinAndSelect("order.orderdetail", "orderdet")
                .where("order.userid = :userid", { userid })
                .andWhere("order.iscart = :iscart", { iscart: 0 })
                .getMany();
            return result;

        }

        //   const data = await this.repo1.createQueryBuilder("order")
        //       .innerJoinAndSelect(OrderDetail, "orderdetail", "orderdetail.orderid = order.id")
        //     .where("order.userid = :userid", { userid })
        //       .getMany();
        //   return data;

        /* const data = await this.repo1.createQueryBuilder("orders")
               .innerJoinAndSelect("OrderDetail","od", "od.orderid = orders.id")
               .where("order.userid = :userid", { userid})
           .getMany();
            return data;*/

    }

    async getSelectedOrder(userid: number, orderid: number): Promise<any> {
        /*  const user = await this.repo1.createQueryBuilder("order")
              .innerJoinAndSelect("order.orderdetail", "orderdet", "orderdet.orderid = :orderid", { orderid: orderid })
              .where("user.userid = :userid", { userid: userid })
              return user;*/
        let result = null;
        result = await getConnection().getRepository("Orders").createQueryBuilder("order")
            .innerJoinAndSelect("order.orderdetail", "orderdet")
            .where("order.userid = :userid", { userid })
            .andWhere("orderdet.orderid=:orderid", { orderid })
            .andWhere("order.iscart = :iscart", { iscart: 0 }).getOne();
        if (result === undefined) {
            return "No Data found";
        }
        return result;

    }

    async deleteOrder(orderid: string): Promise<any> {
        //  return await this.delete(orderid)
        await getConnection()
            .createQueryBuilder()
            .delete()
            .from(OrderDetail)
            .where("orderid = :orderid", { orderid })
            .execute();
        await getConnection()
            .createQueryBuilder()
            .delete()
            .from(Orders)
            .where("id = :id", { id: orderid })
            .execute();
    }
    async deleteproductOrder(orderid: string, prodcutID: string): Promise<any> {
        const result = await getConnection()
            .createQueryBuilder()
            .delete()
            .from(OrderDetail)
            .where("orderid = :orderid", { orderid })
            .andWhere("productid=:prodcutID", { prodcutID })
            .execute();
        return result.affected

    }
    async buyProduct(productIds: any[], userid: number): Promise<any> {
        const orderdata = new Orders();
        orderdata.iscart = false;
        orderdata.userid = userid.toString();
        const orderitemarray: OrderDetail[] = [];


        for (const data of productIds) {
            const orderitem = new OrderDetail();
            orderitem.id = null;
            orderitem.productid = data.productid;
            orderitem.quantity = data.quantity;
            orderitemarray.push(orderitem)
        }
        orderdata.orderdetail = orderitemarray;
        const returnresult = await getConnection().getRepository("Orders").save(orderdata);
        const tracks = orderdata.orderdetail.map(d => ({
            ...d,
            orderid: returnresult.id,
        }));
        const data1 = await getConnection().getRepository("orderdetail").save(tracks);
        if (data1 === undefined) {
            return true;
        }
        else {
            return false;
        }
    }

    async addProdcutCart(productids: any[], userid: number): Promise<any> {
        const data = await getConnection().getRepository<Orders>("Orders").findOne({ where: { iscart: true, userid }});
        const orderitemarray: OrderDetail[] = [];

        if (data !== undefined) {
            for (const d of productids) {
                const orderitem = new OrderDetail();
                orderitem.orderid = data.id.toString();
                orderitem.productid = d.productid;
                orderitem.quantity = d.quantity;
                orderitemarray.push(orderitem)
            }
            const data1 = await getConnection().getRepository("orderdetail").save(orderitemarray);
            if (data1 !== undefined) {
                return true;
            }
            else {
                return false;
            }
        }
        else {
            const orderdata = new Orders();
            orderdata.iscart = true;
            orderdata.userid = userid.toString();


            for (const d1 of productids) {
                const orderitem = new OrderDetail();
                orderitem.id = null;
                orderitem.productid = d1.productid;
                orderitem.quantity = d1.quantity;
                orderitemarray.push(orderitem)
            }
            orderdata.orderdetail = orderitemarray;
            const returnresult = await getConnection().getRepository("Orders").save(orderdata);
            const tracks = orderdata.orderdetail.map(d => ({
                ...d,
                orderid: returnresult.id,
            }));
            const data1 = await getConnection().getRepository("orderdetail").save(tracks);
            if (data1 !== undefined) {
                return true;
            }
            else {
                return false;
            }
        }
    }
    async buyShoppingCart( userid: number): Promise<boolean> {
        const item = await getConnection().getRepository<Orders>("Orders").findOne({ where: { iscart: true, userid } });

        item.iscart = false;
        const data1 = await await getConnection().getRepository<Orders>("Orders").save(item);
        if(data1!==undefined)
        return true;
        else
        return false;

    }

}

export interface IorderRepository {
    getAllOrder(userid: number, iscart: boolean): Promise<OrderDetail[]>;
    getSelectedOrder(userid: number, orderid: number): Promise<OrderDetail>;
    deleteOrder(orderId: string): Promise<any>;
    deleteproductOrder(orderid: string, prodcutID: string): Promise<any>
    buyProduct(productIds: any[], userid: number): Promise<any>
    addProdcutCart(productids: any[], userid: number): Promise<any>;
    buyShoppingCart(userid: number): Promise<boolean>;
}

