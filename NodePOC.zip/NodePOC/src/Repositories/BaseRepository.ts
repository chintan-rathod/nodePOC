import { IWrite } from "./iWrite";
import { IRead } from "./IRead";
import { getManager } from "typeorm";
import { Product } from "../model/product";
import { injectable, unmanaged } from "inversify";
import TYPES from "../type";



@injectable()
// that class only can be extended
export abstract class BaseRepository<T> implements IWrite<T>, IRead<T> {


  // we created constructor with arguments to manipulate mongodb operations
  repo1: any;
  constructor(  repo: any) {
    this.repo1 = repo;
  }
  // we add to method, the async keyword to manipulate the insert result
  // of method.
  async create(item: T): Promise<T> {

    const data1 =  await this.repo1.save(item);
    return data1;
  }


  async update(id: string, item: T): Promise<T> {
    let data = await this.repo1.findOne(id);
    data= item;
   const data1=   await this.repo1.save(data);
   return data1;

  }
  async delete(id: string): Promise<boolean> {
    const data = await  this.repo1.findOne(id);
     return this.repo1.remove(data);

  }
  find(): Promise<T[]> {

    return this.repo1.find();
  }
  findOne(id: string): Promise<T> {
    return this.repo1.findOne(id);
  }

}