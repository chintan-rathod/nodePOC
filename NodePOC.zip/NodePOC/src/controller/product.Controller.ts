import * as express from "express";
import { IProductService, ProductService } from "../services/product.service";
import {
    controller, httpGet, interfaces, requestParam, httpPost, httpDelete,request, httpPut
} from "inversify-express-utils";
import { inject, injectable } from "inversify";
import { Product } from "../model/product";
import TYPES from "../type";
import { promises } from "fs";



@controller("/api/products")

export class ProductController     {


    constructor(@inject(TYPES.ProductService) private prodser: ProductService) {

    }



      @httpGet("/")
     private async getproduct(req: express.Request, res: express.Response, next: express.NextFunction): Promise<Product[]> {
          return this.prodser.getAllProduct(false, null);
     }
    @httpGet("/:vendorNo")
    private async list(req: express.Request, @requestParam("vendorNo") vendorNo: number, res: express.Response, next: express.NextFunction): Promise<Product[]> {
        return this.prodser.getAllProduct(true, vendorNo);
    }

    @httpGet("/id/:id")
    private getSingleProduct(@requestParam("id") id: string, res: express.Response, next: express.NextFunction): Promise<Product> {

        return this.prodser.getSelectedProduct(id);
    }
    @httpPut("/update")
    private update( req: express.Request, res: express.Response, next: express.NextFunction): Promise<Product> {

        return   this.prodser.updateProduct(req.body);
    }
    @httpDelete("/productid/:id")
    private deleteproduct(@requestParam("id") id: string, res: express.Response, next: express.NextFunction): Promise<any> {
        return this.prodser.deleteProduct(id);
    }
    @httpPost("/add")
    private create( req: express.Request, res: express.Response, next: express.NextFunction): Promise<Product> {
        return this.prodser.addProduct(req.body);
    }


}


