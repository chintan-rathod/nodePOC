import * as express from "express";
import { IProductService, ProductService } from "../services/product.service";
import {
    controller, httpGet, interfaces, requestParam, httpPost, httpDelete,request, httpPut
} from "inversify-express-utils";
import { inject, injectable } from "inversify";
import TYPES from "../type";
import { promises } from "fs";
import { OrderService } from "../services/order.service";
import { OrderDetail } from "../model/orderdetail";
import { json } from "body-parser";



@controller("/api/orders")

export class OrderController     {


    constructor(@inject(TYPES.OrderService) private ordser: OrderService) {

    }

     // Get all orders based on user id
    @httpGet("/:userid")
    private async getAllOrders(req: express.Request, @requestParam("userid") userid: number, res: express.Response, next: express.NextFunction): Promise<OrderDetail[]> {
        return this.ordser.getAllOrder(userid,false);
    }
    // get the cart  items based on user id
    @httpGet("/cart/:userid")
    private async getcartItems(req: express.Request, @requestParam("userid") userid: number, res: express.Response, next: express.NextFunction): Promise<OrderDetail[]> {
        return await this.ordser.getAllOrder(userid,true);
    }

    // Get selected order of user
    @httpGet("/selected/:userid/:orderid")
    private async getSelectedOders(req: express.Request,@requestParam("orderid") orderid: number, @requestParam("userid") userid: number, res: express.Response, next: express.NextFunction): Promise<OrderDetail> {
        return await  this.ordser.getSelectedOrder(userid, orderid);
    }

     // Delete/Cancel  specific order
    @httpDelete("/:orderid")
    private async deleteorder(@requestParam("orderid") orderID: string, res: express.Response, next: express.NextFunction): Promise<any> {
         const result = await this.ordser.deleteOrder(orderID);
         if(result)
         {
             return Promise.resolve( JSON.stringify("Data deleted sucessfully."));
         }
         else
         {
            return Promise.resolve( JSON.stringify("No data to delete."));
         }
    }
// Delete product from the cart
    @httpDelete("/product/:orderid/:productid")
    private async deleteproduct(@requestParam("orderid") orderID: string ,@requestParam("productid") productid: string, res: express.Response, next: express.NextFunction): Promise<any> {
         const result = await this.ordser.deleteproductcart(orderID,productid);
         if(result)
         {
             return Promise.resolve( JSON.stringify("Data deleted sucessfully."));
         }
         else
         {
            return Promise.resolve( JSON.stringify("No data to delete."));
         }
    }

    //  Directly  buy multiple  product : can pass array like below
    // [ {"productid":23,"quantity":2} ,{"productid":21,"quantity":2},{"productid":24,"quantity":2},{"productid":25,"quantity":2}]
    @httpPost("/buy/:userid")
    private buy( @requestParam("userid") userid: number,req: express.Request, res: express.Response, next: express.NextFunction): Promise<boolean> {
      return   this.ordser.buyproduct(req.body,userid);
    }

    // Add to cart
    @httpPost("/addproduct/:userid/")
    private addproduct(@requestParam("userid") userid: number, req: express.Request, res: express.Response, next: express.NextFunction): Promise<boolean> {
        return this.ordser.addProdcutCart(req.body,userid);
    }
 // buy from shopping cart
    @httpPost("/buyshoppingcart/:userid/")
    private buyshoppingcart(@requestParam("userid") userid: number, req: express.Request, res: express.Response, next: express.NextFunction): Promise<boolean> {
        return this.ordser.buyShoppingCart(userid);
    }


}


