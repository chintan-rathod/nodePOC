import { Product } from "../model/product";
import { injectable, inject } from "inversify";
import TYPES from "../type";
import { ProductRepository } from "../Repositories/productRepository";


@injectable()
export class ProductService implements IProductService {
    @inject(TYPES.ProductRepository)
    public prodrepo: ProductRepository

    async getAllProduct(flag: boolean, vendorNo: number): Promise<Product[]> {
        return await this.prodrepo.getAllProduct(flag, vendorNo);
    }
    async getSelectedProduct(id: string): Promise<Product> {
        return await this.prodrepo.getSelectedProduct(id);
    }
    async updateProduct(poductdetail: Product): Promise<Product> {

        return await this.prodrepo.updateProduct(poductdetail)

    }
    async deleteProduct(id: string): Promise<any> {
        return await this.prodrepo.deleteProduct(id)
    }
    async addProduct(poductdetail: Product): Promise<Product> {
        return await this.prodrepo.create(poductdetail)
    }




}

export interface IProductService {
        prodrepo: ProductRepository
    getAllProduct(flag: boolean, vendorNo: number): Promise<Product[]>;
    getSelectedProduct(id: string): Promise<Product>;
    updateProduct(poductdetail: Product): Promise<Product>;
    deleteProduct(id: string): Promise<any>;
    addProduct(poductdetail: Product): Promise<Product>;
}