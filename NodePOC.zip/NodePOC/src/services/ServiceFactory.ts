import { Container } from "inversify";
import "reflect-metadata";
import { IProductService, ProductService } from "./product.service";
import TYPES from "../type";
import {   IproductRepository } from "../Repositories/productRepository";
import { ProductRepository } from "../Repositories/productRepository";


const container = new Container();
 container.bind<IProductService>(TYPES.ProductService).to(ProductService);
 container.bind<IproductRepository>(TYPES.ProductRepository).to(ProductRepository);
export default container;
