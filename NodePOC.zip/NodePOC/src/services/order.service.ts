import { Product } from "../model/product";
import { injectable, inject } from "inversify";
import TYPES from "../type";
import { ProductRepository } from "../Repositories/productRepository";
import { OrderDetail } from "../model/orderdetail";

import { OrderRepository } from "../Repositories/orderRepository";
import { promises } from "fs";


@injectable()
export class OrderService implements IorderService {
    @inject(TYPES.OrderRepository)
    public orderrepo: OrderRepository

    async getAllOrder(userid: number, iscart: boolean): Promise<OrderDetail[]> {
        return await this.orderrepo.getAllOrder(userid, iscart);
    }
    async getSelectedOrder(userid: number, orderid: number): Promise<OrderDetail> {
        return await this.orderrepo.getSelectedOrder(userid, orderid);
    }

    async deleteOrder(orderId: string): Promise<boolean> {
        return await this.orderrepo.deleteOrder(orderId)
    }
    async deleteproductcart(orderId: string, productID: string): Promise<boolean> {
        const result = await this.orderrepo.deleteproductOrder(orderId, productID)
        if (result > 0) {
            return true
        }
        return false;
    }
    async buyproduct(productids: any[], userid: number): Promise<boolean> {
        const result = await this.orderrepo.buyProduct(productids, userid)
        return result;
    }

    async addProdcutCart(productids: any[], userid: number): Promise<boolean> {
        const result = await this.orderrepo.addProdcutCart(productids, userid)
        return result;
    }
   async  buyShoppingCart(userid: number): Promise<boolean>
   {
    const result = await this.orderrepo.buyShoppingCart( userid)
    return result;

   }

}

export interface IorderService {

    getAllOrder(userid: number, iscart: boolean): Promise<OrderDetail[]>;
    getSelectedOrder(userid: number, orderid: number): Promise<OrderDetail>;
    deleteOrder(orderId: string): Promise<boolean>;
    deleteproductcart(orderId: string, productID: string): Promise<boolean>;
    buyproduct(productids: any[], userid: number): Promise<boolean>;
    addProdcutCart(productids: any[], userid: number): Promise<boolean>
    buyShoppingCart(userid: number): Promise<boolean>;

}