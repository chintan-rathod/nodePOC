
import 'reflect-metadata';
import * as bodyParser from "body-parser";
import express from "express";
import { TYPE, interfaces, InversifyExpressServer } from "inversify-express-utils";
import   "./controller/product.Controller";
import   "./controller/order.Controller";
import { IProductService, ProductService } from "./services/product.service";

import { Container } from "inversify";
import TYPES from "./type";
import { IproductRepository, ProductRepository } from './Repositories/productRepository';
import { getSqlDbConnection } from './Repositories/dbConnction';
import { Product } from './model/product';
import { getRepository,Repository as TypeOrmRepository } from 'typeorm';
import { bootstrapProcess } from './boostrap';



class App {

  public app: express.Application;

  constructor(  public controllers: any[], public port: number | string) {

    this.port = port;

    // this.initializeMiddlewares();
    // this.initializeControllers(controllers);
  }

  public async  listen() {

  await   bootstrapProcess( Number(this.port))

// console.log('Server started on port :'+this.port);
  }

  private initializeMiddlewares() {
    this.app.use(bodyParser.json());
  }

  private initializeControllers(controllers: any[]) {
    controllers.forEach((controller) => {
      this.app.use("/", controller.router);
    });
  }
}

export default App;
